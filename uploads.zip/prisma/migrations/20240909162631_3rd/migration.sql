-- AlterTable
ALTER TABLE `Vacancy` MODIFY `gender` ENUM('Male', 'Female', 'Both') NOT NULL;
