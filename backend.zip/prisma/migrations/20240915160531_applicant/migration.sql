-- AlterTable
ALTER TABLE `Employee` MODIFY `lName` VARCHAR(191) NULL;
